Use https://www.googleapis.com/books/v1/volumes?q= url to test search functionality 


API Search TODO:
* get a loop to display mutiple results [DONE]
    * decided how many books we want displayed per search 
* get search value and add it to the API call so user can search [DONE]
    * Remember to delete old dom elements on search [DONE]
* lock down what data we want to display
* figure out why key isn't working
* make it look nice 